package test;

public class Question1 {
    public static void main(String[] args) {
        int n1 =5;
        int n2 =7;

        System.out.printf("%d + %d = %d\n",n1,n2,(n1+n2));
        System.out.printf("%d X %d = %d\n",n1,n2,(n1*n2));
    }
}
